﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectFirst.Infrastucture.Service;
using ProjectFirst.Models;
using System.Security.Claims;

namespace ProjectFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Customer")]
    public class Order_ItemsController : ControllerBase
    {
        private readonly IOrder_Item order_ItemRepo;
        private readonly ICart cartRepo;

        public Order_ItemsController(IOrder_Item order_ItemRepo, ICart cartRepo)
        {
            this.order_ItemRepo = order_ItemRepo;
            this.cartRepo = cartRepo;
        }
        [HttpPost("{orderId}")]
        
        public  IActionResult AddOrderedItems([FromRoute]Guid orderId)
        {
            var id = int.Parse(HttpContext.User.FindFirst(c => c.Type == "UserId").Value);
            order_ItemRepo.AddOrderdItems(id, orderId);
            return Ok();
        }

        [HttpGet("AllOrders")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetOrderedItems()
        {
            
            var result = order_ItemRepo.GetAllOrders();
            return Ok(result);
        }



        [HttpGet]
        [Route("getOrderItems")]
        public IActionResult GetOrderItems()
        {
            int id = int.Parse(HttpContext.User.FindFirst(t => t.Type == "UserId").Value);
            var result = cartRepo.GetAllCartItems(id);

            return Ok(result) ;
        }

        [HttpGet("{orderId}")]
        
        public IActionResult GetOrderedItems(Guid orderId)
        {
            int id = int.Parse(HttpContext.User.FindFirst(t => t.Type == "UserId").Value);
            var result = order_ItemRepo.GetOrderedItems(orderId,id);
            return Ok(result);
        }

        [HttpGet("MyOrders")]
        public async Task<IActionResult> GetMyOrders()
        {
            int id = int.Parse(HttpContext.User.FindFirst(t => t.Type == "UserId").Value);
            var result =await order_ItemRepo.GetMyOrders(id);
            return Ok(result);
        }
    }

}
