﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjectFirst.DTO;
using ProjectFirst.Infrastucture.Service;
using ProjectFirst.Models;

namespace ProjectFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUser userInterface;

        public UserController(IUser userInterface)
        {
            this.userInterface = userInterface;

        }

        

        [HttpGet]
        [Authorize(Roles ="Admin")]
        public async Task<ActionResult<User>> GetAllUsers()
        {
            var result =await userInterface.GetAll();
            if(result != null)
            {
                return Ok(result);
            }
            return NotFound();
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Customer")]
        public async Task<ActionResult<User>> UpdateUser([FromBody] User user)
        {
            int id = int.Parse(HttpContext.User.FindFirst("userId").Value);
            var result = await userInterface.UpdateUserDetail(id, user);
            if(result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpPost("login")]
        public LoginResponseDTO Login([FromBody]LoginRequestDTO loginDto)
        {
            var result=  userInterface.Login(loginDto);

            if(result != null)
            {
                return result;
            }
            return null;
        }

        [HttpPost]
        public async Task<ActionResult<User>> AddUser([FromBody]User user)
        {
            var result= await userInterface.AddUserAsync(user);
            if(result != null)
            {
                return Ok(result);
            }
            return BadRequest("User already exist.Please login");
            
        }



    }
}
