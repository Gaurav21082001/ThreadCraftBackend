﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjectFirst.Infrastucture.Implementation;
using ProjectFirst.Infrastucture.Service;
using ProjectFirst.Models;

namespace ProjectFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles ="Customer")]
    public class CartsController : ControllerBase
    {
        private readonly ICart cartRepo;

        public CartsController(ICart cartRepo)
        {
            this.cartRepo = cartRepo;
        }

        // GET: api/Carts
        [HttpGet]
        [Route("GetCartItems")]
       // [Authorize(Roles = "Customer")]
        public async Task<ActionResult<IEnumerable<Cart>>> GetCarts()
        {
            var result= cartRepo.GetAllCartItems(GetIdFromToken());
            return Ok(result);
        }

        
        // PUT: api/Carts/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut]
        [Route("UpdateCartItemsDatabase")]
       // [Authorize(Roles = "Customer")]
        public async Task<IActionResult> UpdateCartDatabase([FromBody] ShoppingCartUpdate[] cartItems )
        {
            try
            {
                cartRepo.UpdateCartItemDB(GetIdFromToken(), cartItems);

            }catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
            return Ok(cartItems);
        }

        // POST: api/Carts
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Route("AddItemToCart/{productId}")]
        
        public async Task<ActionResult<Cart>> PostCart(int productId)
        {
            var result=await cartRepo.AddToCart(productId, GetIdFromToken());


            return Ok(result);
        }

        // DELETE: api/Carts/5
        [HttpDelete]
        [Route("RemoveItem/{productId}")]
        
        public async Task<IActionResult> RemoveItem( int productId)
        {
            var cart = await cartRepo.RemoveItem(productId, GetIdFromToken());
            if (cart == null)
            {
                return NotFound();
            }
            return Ok();
           
        }

        [HttpGet]
        [Route("TotalPrice")]
        public ActionResult<int> GetTotalPrice()
        {
            var result=cartRepo.GetToTalPrice(GetIdFromToken());
            return Ok(result);
        }

        private int GetIdFromToken()
        {
            var id = HttpContext.User.FindFirst("userId").Value;
            return int.Parse(id);
        }

        [HttpPut]
        [Route("updateItem/{productId}")]
      //  [Authorize(Roles = "Customer")]
        public IActionResult UpdateItem([FromRoute] int productId,[FromBody]int quantity)
        {
            cartRepo.UpdateItem(GetIdFromToken(), productId, quantity);
            return Ok();
        }

        [HttpDelete]
        [Route("EmptyCart")]
      //  [Authorize(Roles = "Customer")]
        public IActionResult EmptyCart()
        {
            cartRepo.EmptyCart(GetIdFromToken());
            return Ok();
        }

        [HttpGet]
        [Route("GetCount")]
      //  [Authorize(Roles = "Customer")]
        public ActionResult<int> TotalCount()
        {
            var result=cartRepo.GetCount(GetIdFromToken());
            return Ok(result);
        }
       
    }
}
