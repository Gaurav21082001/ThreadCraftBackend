﻿using ProjectFirst.Models;

namespace ProjectFirst.Infrastucture.Service
{
    public interface IOrder_Item
    {
        Task<IEnumerable<Order_Items>> GetOrderedItems(Guid orderId, int userId);

        Task<IEnumerable<Order_Items>> GetAllOrders();
        void AddOrderdItems(int userId, Guid orderId);
        Task<IEnumerable<Order_Items>> GetMyOrders(int userId);
    }
}
