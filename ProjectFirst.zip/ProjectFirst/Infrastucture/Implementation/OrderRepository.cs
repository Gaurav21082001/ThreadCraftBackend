﻿using ProjectFirst.Infrastucture.Service;
using ProjectFirst.Models;
using System.Security.Claims;

namespace ProjectFirst.Infrastucture.Implementation
{
    public class OrderRepository : IOrder
    {
        private readonly ProjectDbContext context;
        private readonly ICart cart;
        
        public OrderRepository(ProjectDbContext context,ICart cart)
        {
            this.context = context;
            this.cart = cart;
            
        }

        public async Task<Order> BuyNow(int userId)
        {
          
           
            var order = new Order
            {
                UserId = userId,
                TotalAmount = GetTotalAmount(userId),
                ShippingCharge = 50,
                NetAmount = GetTotalAmount(userId) + 50
            };
            
            var result =await context.Orders.AddAsync(order);
             context.SaveChangesAsync();
            return result.Entity;
        }

        public void EmptyCart(int userId)
        {
            var items = context.Carts.Where(t => t.UserId == userId).ToList();
            foreach (var item in items)
            {
                context.Carts.Remove(item);
            }
        }
       
        public int GetNetAmount(int userId)
        {
            var total = context.Orders.FirstOrDefault(t => t.UserId == userId).NetAmount;
            return total;
             
        }

        public int GetTotalAmount(int userId)
        {
            
            return cart.GetToTalPrice(userId);
        }
    }
}
