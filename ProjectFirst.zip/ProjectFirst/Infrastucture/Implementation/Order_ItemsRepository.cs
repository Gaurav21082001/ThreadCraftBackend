﻿using Microsoft.EntityFrameworkCore;
using ProjectFirst.Infrastucture.Service;
using ProjectFirst.Models;

namespace ProjectFirst.Infrastucture.Implementation
{
    public class Order_ItemsRepository : IOrder_Item
    {
        private readonly ProjectDbContext context;
        
        public Order_ItemsRepository(ProjectDbContext context)
        {
            this.context = context;
        }
        public void AddOrderdItems(int userId,Guid orderId)
        {
            var cartItems=context.Carts.Where(t => t.UserId == userId).ToList();
            foreach (var cartItem in cartItems)
            {
                var orderItem = new Order_Items
                {
                    ProductId = cartItem.ProductId,
                    OrderId= orderId,
                    ProductName =context.Products.FirstOrDefault(t=>t.ProductId==cartItem.ProductId).ProductName,
                    UserId = userId,
                    Quantity = cartItem.Quantity,
                    Price = cartItem.UnitPrice,
                    TotalAmount = cartItem.Quantity * cartItem.UnitPrice,

                };
                context.Order_Items.Add(orderItem);
                context.SaveChanges();

            }
        }
        public async Task<IEnumerable<Order_Items>> GetOrderedItems(Guid orderId,int userId)
        {
           var result= context.Order_Items.Where(t=>t.UserId == userId && t.OrderId==orderId).ToList();

            return result;
        }

        public async Task<IEnumerable<Order_Items>> GetMyOrders(int userId)
        {
            var result=await context.Order_Items.Where(t=>t.UserId==userId).ToListAsync();
            return result;
        }

        public async Task<IEnumerable<Order_Items>> GetAllOrders()
        {
            var result = await context.Order_Items.ToListAsync();
            return result;
        }
    }
}
