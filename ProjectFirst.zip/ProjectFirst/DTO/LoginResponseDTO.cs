﻿namespace ProjectFirst.DTO
{
    public class LoginResponseDTO
    {
        public string Token {  get; set; }

    }
}
